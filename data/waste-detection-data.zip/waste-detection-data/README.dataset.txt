# Waste Detection > 2023-10-07 12:02am
https://universe.roboflow.com/ata-tekeli-f29e1/waste-detection-2kuxm

Provided by a Roboflow user
License: MIT

